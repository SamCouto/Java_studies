import java.util.Locale;

public class Main {

	public static void main(String[] args) {
		
		//Variables
		String product1 = "Computer";
		String product2 = "Office Desk";
		
		int age = 30;
		int code = 5290;
		char gender = 'f';
		
		double price1 = 2100.0;
		double price2 = 650.50;
		double measure = 53.234567;
		
		//Printing the product informations
		System.out.println("Products:");
		System.out.println(product1 + ", which price is $" + price1);
		System.out.println(product2 + ", which price is $" + price2);
		System.out.println("");
		
		//Printing record informations
		System.out.println("Record: " + age + " years old, code: " + code + " and gender: " + gender);
		System.out.println("");
		
		//Printing measures informations
		System.out.println("Measure with eight decimal places: " + measure);
		System.out.printf("Rounded (three decimal places): %.2f%n", measure);
		
		//Printing the informations with a foreign notation system
		Locale.setDefault(Locale.UK);
		System.out.printf("United Kingdom decimal point: %.2f%n", measure);

	}

}
